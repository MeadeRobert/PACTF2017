def solution(cutoff_string, final_hash):
    """
    Implement your solution here. See 'problem.pdf' for details.
    """
    return "<solution>"
